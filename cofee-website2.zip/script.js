/* =========================================
   TEMEL ARAYÜZ, TOAST VE MENÜ
   ========================================= */
function toggleMenu() { document.getElementById('navLinks').classList.toggle('active'); }

function closeMenu() { document.getElementById('navLinks').classList.remove('active'); }
window.addEventListener('scroll', () => {
  const navbar = document.querySelector('.navbar');
  if (window.scrollY > 50) {
    navbar.style.top = '0';
    navbar.style.padding = '10px 5%';
  } else {
    navbar.style.top = window.innerWidth < 900 ? '28px' : '35px';
    navbar.style.padding = '12px 5%';
  }
});

function showToast(message, type = 'success') {
  const container = document.getElementById('toast-container');
  const toast = document.createElement('div');
  toast.classList.add('toast', type);
  let icon = type === 'error' ? '<i class="fa-solid fa-circle-exclamation" style="color:#ff4d4d"></i>' : '<i class="fa-solid fa-check-circle" style="color:#25D366"></i>';
  toast.innerHTML = `${icon} <span>${message}</span>`;
  container.appendChild(toast);
  setTimeout(() => {
    toast.style.animation = 'slideOut 0.3s forwards';
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

/* =========================================
   HAVA DURUMU & MÜZİK
   ========================================= */
fetch('https://api.open-meteo.com/v1/forecast?latitude=38.08&longitude=46.29&current_weather=true')
  .then(res => res.json())
  .then(data => { document.getElementById('weatherTemp').innerText = `${Math.round(data.current_weather.temperature)}°C`; })
  .catch(() => { document.getElementById('weatherTemp').innerText = '18°C'; });

let isMusicPlaying = false;

function toggleMusic() {
  const audio = document.getElementById('bgMusic');
  const icon = document.getElementById('music-icon');
  if (isMusicPlaying) {
    audio.pause();
    icon.classList.remove('playing');
    showToast('Music paused');
  } else {
    audio.volume = 0.3;
    audio.play().catch(e => console.log("Tarayıcı engeli"));
    icon.classList.add('playing');
    showToast('Music playing');
  }
  isMusicPlaying = !isMusicPlaying;
}

/* =========================================
   DİL DESTEĞİ & TEMA
   ========================================= */
let currentLang = 'en';

function changeLanguage(lang) {
  currentLang = lang;
  document.documentElement.lang = lang;
  document.querySelectorAll('.lang-btn').forEach(btn => btn.classList.remove('active'));
  document.getElementById(`lang-${lang}`).classList.add('active');
  if (lang === 'fa') document.body.setAttribute('dir', 'rtl');
  else document.body.removeAttribute('dir');
  
  document.querySelectorAll('[data-en]').forEach(el => {
    if (el.tagName === 'INPUT') el.setAttribute('placeholder', el.getAttribute(`data-${lang}-ph`));
    else el.innerText = el.getAttribute(`data-${lang}`);
  });
  showToast(`Language changed to ${lang.toUpperCase()}`);
}

function toggleTheme() {
  document.body.classList.toggle('light-mode');
  document.getElementById('theme-icon').classList.toggle('fa-sun');
  document.getElementById('theme-icon').classList.toggle('fa-moon');
}

/* =========================================
   GÜNÜN MENÜSÜ (SAAT BAZLI)
   ========================================= */
function setDailyMenu() {
  const hour = new Date().getHours();
  const title = document.getElementById('dailyTitle');
  const desc = document.getElementById('dailyDesc');
  const img = document.getElementById('dailyImage');
  const btn = document.querySelector('.daily-text button');
  const badge = document.querySelector('.badge');
  
  if (!title) return;
  
  if (hour >= 6 && hour < 12) {
    badge.innerText = "Morning Boost";
    title.innerText = "Start Fresh";
    desc.innerText = "Our special morning coffee and croissant combo to wake you up.";
    img.src = "./images/hot-beverages.png";
    btn.innerText = "Order Now - $5.00";
    btn.onclick = () => addToCart('Morning Coffee', 5.00, './images/hot-beverages.png', 'İçecek');
  } else if (hour >= 12 && hour < 18) {
    badge.innerText = "Lunch Special";
    title.innerText = "Midday Feast";
    desc.innerText = "Fuel your afternoon with our signature Burger Menu.";
    img.src = "./images/burger-frenchfries.png";
    btn.innerText = "Order Now - $8.50";
    btn.onclick = () => addToCart('Burger Menu', 8.50, './images/burger-frenchfries.png', 'Tuzlu');
  } else {
    badge.innerText = "Dinner Combo";
    title.innerText = "Evening Delight";
    desc.innerText = "Relax with our Special Combo and a cold beverage.";
    img.src = "./images/special-combo.png";
    btn.innerText = "Order Now - $6.00";
    btn.onclick = () => addToCart('Special Combo', 6.00, './images/special-combo.png', 'Tuzlu');
  }
}

/* =========================================
   KUPON ÇARKI (SPIN TO WIN)
   ========================================= */
let isSpinning = false;

function toggleWheelModal() {
  document.getElementById('wheelModal').classList.toggle('active');
  document.getElementById('wheelOverlay').classList.toggle('active');
}

function spinWheel() {
  if (isSpinning) return;
  isSpinning = true;
  const spinBtn = document.getElementById('spinBtn');
  spinBtn.innerText = "Spinning...";
  spinBtn.style.opacity = '0.5';
  
  const wheel = document.getElementById('wheel');
  const prizes = ["%10 OFF", "FREE COFFEE", "TRY AGAIN", "%20 OFF", "FREE DESSERT", "TRY AGAIN", "%15 OFF", "FREE FRIES"];
  const randomPrizeIndex = Math.floor(Math.random() * 8);
  const targetDegree = (5 * 360) + (randomPrizeIndex * 45) + 22.5;
  
  wheel.style.transform = `rotate(${targetDegree}deg)`;
  
  setTimeout(() => {
    isSpinning = false;
    spinBtn.innerText = "SPIN NOW";
    spinBtn.style.opacity = '1';
    
    const wonPrize = prizes[randomPrizeIndex];
    
    if (wonPrize === "TRY AGAIN") {
      showToast("Try again next time! 😢", "error");
    } else if (wonPrize.includes("OFF")) {
      showToast(`Congratulations! You won ${wonPrize}!`, 'success');
      document.getElementById('couponInput').value = "TABRIZ20";
      appliedDiscount = 0.20;
    } else {
      showToast(`Amazing! You won a ${wonPrize}!`, 'success');
    }
    
    toggleWheelModal();
  }, 4000);
}

/* =========================================
   SİPARİŞ TAKİBİ (CHECKOUT ANİMASYONU)
   ========================================= */
function startOrderTracking() {
  document.getElementById('trackingModal').classList.add('active');
  document.getElementById('trackingOverlay').classList.add('active');
  
  document.querySelectorAll('.track-step').forEach(step => step.classList.remove('active'));
  document.getElementById('step-1').classList.add('active');
  
  setTimeout(() => { document.getElementById('step-2').classList.add('active'); }, 2500);
  setTimeout(() => { document.getElementById('step-3').classList.add('active'); }, 5000);
  setTimeout(() => {
    document.getElementById('step-4').classList.add('active');
    showToast('Order Delivered! Enjoy your meal. 🍔', 'success');
  }, 8000);
}

function closeTrackingModal() {
  document.getElementById('trackingModal').classList.remove('active');
  document.getElementById('trackingOverlay').classList.remove('active');
}

/* =========================================
   FAVORİLER (WISHLIST) SİSTEMİ
   ========================================= */
let wishlist = [];

function toggleWishlistSidebar() {
  document.getElementById('wishlistSidebar').classList.toggle('active');
  document.getElementById('wishlistOverlay').classList.toggle('active');
}

function toggleWishlist(name, price, image) {
  const existingIndex = wishlist.findIndex(item => item.name === name);
  
  if (existingIndex > -1) {
    wishlist.splice(existingIndex, 1);
    showToast(`${name} removed from wishlist.`, 'error');
  } else {
    wishlist.push({ name, price, image });
    showToast(`${name} added to wishlist!`, 'success');
  }
  updateWishlistUI();
}

function updateWishlistUI() {
  const container = document.getElementById('wishlistItemsContainer');
  const count = document.getElementById('wishlist-count');
  
  container.innerHTML = '';
  if (wishlist.length === 0) {
    container.innerHTML = `<p class="empty-cart-msg">Your wishlist is empty.</p>`;
  } else {
    wishlist.forEach((item, index) => {
      container.innerHTML += `
                <div class="cart-item">
                    <img src="${item.image}" alt="${item.name}">
                    <div class="cart-item-info">
                        <h4>${item.name}</h4>
                        <p>$${item.price.toFixed(2)}</p>
                    </div>
                    <button class="add-to-cart" onclick="addToCart('${item.name}', ${item.price}, '${item.image}', 'Genel')"><i class="fa-solid fa-cart-plus"></i></button>
                    <button class="remove-item" onclick="toggleWishlist('${item.name}', ${item.price}, '${item.image}')"><i class="fa-solid fa-trash"></i></button>
                </div>`;
    });
  }
  count.innerText = wishlist.length;
}

/* =========================================
   ÜRÜN YORUMLARI SİSTEMİ
   ========================================= */
let currentProduct = "";
let currentRating = 5;
let productReviews = {
  "Burger Menu": [{ name: "Ali", rating: 5, text: "Harika bir burger, kesinlikle tavsiye ederim!" }],
  "Special Combo": [{ name: "Ayşe", rating: 4, text: "Porsiyon çok iyiydi." }]
};

function openProductModal(title, price, imgSrc, description, calories) {
  currentProduct = title;
  document.getElementById('modalTitle').innerText = title;
  document.getElementById('modalPrice').innerText = `$${price.toFixed(2)}`;
  document.getElementById('modalImg').src = imgSrc;
  document.getElementById('modalDesc').innerText = description;
  document.getElementById('modalCalories').innerText = calories;
  
  document.getElementById('modalAddBtn').onclick = function() {
    addToCart(title, price, imgSrc, 'Genel');
    closeProductModal();
  };
  
  loadProductReviews(title);
  document.getElementById('productModal').classList.add('active');
  document.getElementById('productOverlay').classList.add('active');
}

function closeProductModal() {
  document.getElementById('productModal').classList.remove('active');
  document.getElementById('productOverlay').classList.remove('active');
}

function loadProductReviews(productName) {
  const list = document.getElementById('modalReviewsList');
  list.innerHTML = '';
  const reviews = productReviews[productName] || [];
  
  if (reviews.length === 0) {
    list.innerHTML = '<p style="font-size:12px; color:#888;">No reviews yet. Be the first!</p>';
  } else {
    reviews.forEach(r => {
      let starsHtml = '';
      for (let i = 0; i < 5; i++) starsHtml += `<i class="fa-solid fa-star" style="${i < r.rating ? 'color:var(--primary)' : 'color:#555'}"></i>`;
      list.innerHTML += `
                <div class="review-item">
                    <div class="review-item-header">
                        <span>${r.name}</span>
                        <div class="stars">${starsHtml}</div>
                    </div>
                    <p>${r.text}</p>
                </div>
            `;
    });
  }
}

function setRating(rating) {
  currentRating = rating;
  document.getElementById('reviewRating').value = rating;
  const stars = document.querySelectorAll('.star-rating i');
  stars.forEach((star, index) => {
    if (index < rating) star.classList.add('active');
    else star.classList.remove('active');
  });
}

function submitReview() {
  const nameInput = document.getElementById('reviewName').value;
  const textInput = document.getElementById('reviewText').value;
  
  if (!nameInput || !textInput) {
    showToast('Please fill name and review!', 'error');
    return;
  }
  
  if (!productReviews[currentProduct]) productReviews[currentProduct] = [];
  productReviews[currentProduct].unshift({ name: nameInput, rating: currentRating, text: textInput });
  showToast('Review submitted successfully!', 'success');
  
  document.getElementById('reviewName').value = '';
  document.getElementById('reviewText').value = '';
  setRating(5);
  loadProductReviews(currentProduct);
}

/* =========================================
   ÜYELİK SİSTEMİ
   ========================================= */
function toggleAuthModal() {
  document.getElementById('authModal').classList.toggle('active');
  document.getElementById('authOverlay').classList.toggle('active');
  checkLoginStatus();
}

function switchAuthTab(tab) {
  document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.auth-form').forEach(f => f.classList.remove('active'));
  if (tab === 'login') {
    document.querySelector('.auth-tab:nth-child(1)').classList.add('active');
    document.getElementById('loginForm').classList.add('active');
  } else {
    document.querySelector('.auth-tab:nth-child(2)').classList.add('active');
    document.getElementById('registerForm').classList.add('active');
  }
  document.getElementById('loginError').innerText = '';
  document.getElementById('registerError').innerText = '';
}

function handleLogin() {
  const email = document.getElementById('loginEmail').value;
  const pass = document.getElementById('loginPassword').value;
  const errorEl = document.getElementById('loginError');
  
  const savedEmail = localStorage.getItem('userEmail');
  const savedPass = localStorage.getItem('userPass');
  
  if (email === savedEmail && pass === savedPass) {
    showToast('Login successful!');
    checkLoginStatus();
  } else {
    errorEl.innerText = 'Invalid email or password!';
  }
}

function handleRegister() {
  const name = document.getElementById('regName').value;
  const email = document.getElementById('regEmail').value;
  const pass = document.getElementById('regPassword').value;
  const errorEl = document.getElementById('registerError');
  
  if (pass.length < 6) {
    errorEl.innerText = 'Password must be at least 6 characters.';
    return;
  }
  
  localStorage.setItem('userName', name);
  localStorage.setItem('userEmail', email);
  localStorage.setItem('userPass', pass);
  if (!localStorage.getItem('userPoints')) localStorage.setItem('userPoints', '0');
  
  showToast(`Welcome, ${name}!`);
  checkLoginStatus();
}

function logoutUser() {
  localStorage.removeItem('userName');
  localStorage.removeItem('userEmail');
  localStorage.removeItem('userPass');
  showToast('Logged out');
  checkLoginStatus();
}

function checkLoginStatus() {
  const name = localStorage.getItem('userName');
  const email = localStorage.getItem('userEmail');
  const points = localStorage.getItem('userPoints') || '0';
  
  const loginForm = document.getElementById('loginForm');
  const registerForm = document.getElementById('registerForm');
  const authTabs = document.getElementById('authTabs');
  const profileScreen = document.getElementById('profileScreen');
  const userIcon = document.getElementById('user-icon');
  
  if (name) {
    loginForm.style.display = 'none';
    registerForm.style.display = 'none';
    authTabs.style.display = 'none';
    profileScreen.style.display = 'block';
    
    document.getElementById('profileName').innerText = name;
    document.getElementById('profileEmail').innerText = email;
    document.getElementById('profilePoints').innerText = points;
    userIcon.classList.replace('fa-user', 'fa-user-check');
  } else {
    loginForm.style.display = 'block';
    authTabs.style.display = 'flex';
    profileScreen.style.display = 'none';
    userIcon.classList.replace('fa-user-check', 'fa-user');
    switchAuthTab('login');
  }
}

/* =========================================
   AI ASİSTAN (CHAT)
   ========================================= */
function toggleAI() {
  document.getElementById('aiModal').classList.toggle('active');
  document.getElementById('aiOverlay').classList.toggle('active');
  setTimeout(() => document.getElementById('aiInput').focus(), 300);
}

function handleAIKeyPress(e) { if (e.key === 'Enter') sendAIMessage(); }

function sendAIMessage() {
  const input = document.getElementById('aiInput');
  const text = input.value.trim();
  if (!text) return;
  
  appendMessage('user', text);
  input.value = '';
  
  const typingId = 'typing-' + Date.now();
  appendMessage('bot', '<i class="fa-solid fa-ellipsis fa-fade"></i>', typingId);
  
  setTimeout(() => {
    document.getElementById(typingId).remove();
    appendMessage('bot', getAIResponse(text));
  }, 1200);
}

function appendMessage(sender, text, id = '') {
  const chatBody = document.getElementById('aiChatBody');
  const msgDiv = document.createElement('div');
  msgDiv.classList.add('chat-message', sender);
  if (id) msgDiv.id = id;
  const icon = sender === 'bot' ? '<i class="fa-solid fa-robot"></i>' : '<i class="fa-solid fa-user"></i>';
  msgDiv.innerHTML = `${icon} <div class="bubble">${text}</div>`;
  chatBody.appendChild(msgDiv);
  chatBody.scrollTop = chatBody.scrollHeight;
}

function getAIResponse(text) {
  text = text.toLowerCase();
  if (text.includes('tatlı') || text.includes('sweet')) return "Tatlı krizin için: <strong>Desserts</strong>! Menüye göz at. 🍰";
  if (text.includes('kahve') || text.includes('coffee')) return "Sana özel bir kahve: <strong>Hot Beverages</strong>! ☕";
  if (text.includes('acıktım') || text.includes('tuzlu') || text.includes('yemek')) return "Karnın açsa, <strong>Special Combo</strong> veya <strong>Burger Menu</strong> tam sana göre! 🍔";
  if (text.includes('merhaba') || text.includes('selam')) return "Merhaba! Tatlı, tuzlu veya içecek arıyorsan bana yazabilirsin. 😊";
  return "Bunu tam anlayamadım ama <strong>Special Combo</strong>'yu denemeni tavsiye ederim. İçecek, tatlı veya tuzlu yazarak tekrar sorabilirsin. 🤖";
}

/* =========================================
   SEPET VE ÖDEME
   ========================================= */
let countdownTime = 2 * 60 * 60 + 45 * 60 + 10;
setInterval(() => {
  const el = document.getElementById('countdown');
  if (!el) return;
  const h = Math.floor(countdownTime / 3600),
    m = Math.floor((countdownTime % 3600) / 60),
    s = countdownTime % 60;
  el.innerText = `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  if (countdownTime > 0) countdownTime--;
}, 1000);

let cart = [],
  appliedDiscount = 0;

function toggleCart() {
  document.getElementById('cartSidebar').classList.toggle('active');
  document.getElementById('cartOverlay').classList.toggle('active');
}

function addToCart(name, price, image, category) {
  const existingItem = cart.find(item => item.name === name);
  if (existingItem) existingItem.quantity += 1;
  else cart.push({ name, price, image, category, quantity: 1 });
  updateCartUI();
  showToast(`${name} added to cart!`);
  const cartIcon = document.querySelector('.cart-icon');
  cartIcon.style.transform = 'scale(1.3)';
  setTimeout(() => cartIcon.style.transform = 'scale(1)', 200);
}

function removeFromCart(index) {
  cart.splice(index, 1);
  updateCartUI();
  showToast(`Item removed.`, 'error');
}

function updateCartUI() {
  const container = document.getElementById('cartItemsContainer');
  const count = document.getElementById('cart-count');
  const totalEl = document.getElementById('cartTotalPrice');
  container.innerHTML = '';
  let subTotal = 0,
    totalItems = 0;
  if (cart.length === 0) {
    container.innerHTML = `<p class="empty-cart-msg">Cart is empty.</p>`;
  } else {
    cart.forEach((item, index) => {
      subTotal += item.price * item.quantity;
      totalItems += item.quantity;
      container.innerHTML += `
                <div class="cart-item">
                    <img src="${item.image}" alt="${item.name}">
                    <div class="cart-item-info"><h4>${item.name}</h4><p>$${item.price.toFixed(2)} x ${item.quantity}</p></div>
                    <button class="remove-item" onclick="removeFromCart(${index})"><i class="fa-solid fa-trash"></i></button>
                </div>`;
    });
  }
  let finalTotal = subTotal - (subTotal * appliedDiscount);
  count.innerText = totalItems;
  totalEl.innerText = `$${finalTotal.toFixed(2)}`;
}

function applyCoupon() {
  const code = document.getElementById('couponInput').value.trim().toUpperCase();
  if (code === 'TABRIZ20') {
    appliedDiscount = 0.20;
    showToast('Coupon applied: 20% OFF!');
  } else {
    appliedDiscount = 0;
    showToast('Invalid coupon code.', 'error');
  }
  updateCartUI();
}

function checkout() {
  if (cart.length === 0) { showToast('Cart is empty!', 'error'); return; }
  let subTotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  let finalTotal = subTotal - (subTotal * appliedDiscount);
  
  if (localStorage.getItem('userName')) {
    let currentPoints = parseInt(localStorage.getItem('userPoints') || '0');
    let earnedPoints = Math.floor(finalTotal * 10);
    localStorage.setItem('userPoints', currentPoints + earnedPoints);
    showToast(`Order successful! Earned ${earnedPoints} points.`);
  } else {
    showToast(`Order successful! Total: $${finalTotal.toFixed(2)}`);
  }
  
  cart = [];
  appliedDiscount = 0;
  document.getElementById('couponInput').value = '';
  updateCartUI();
  toggleCart();
  
  setTimeout(() => startOrderTracking(), 500);
}

/* =========================================
   SCROLL ANIMASYONLARI VE BAŞLANGIÇ
   ========================================= */
const revealEls = document.querySelectorAll('.feature-card, .card, .about-container, .hero-content, .gallery-item, .stat-box, .contact-container, .insta-item, .daily-container');
const revealOnScroll = () => {
  revealEls.forEach((el) => {
    if (el.getBoundingClientRect().top < window.innerHeight - 100) {
      el.style.opacity = '1';
      el.style.transform = 'translateY(0)';
    } else {
      el.style.opacity = '0';
      el.style.transform = 'translateY(40px)';
    }
  });
};
revealEls.forEach((el) => { el.style.transition = 'all 0.6s ease-out';
  el.style.opacity = '0'; });
window.addEventListener('scroll', revealOnScroll);
window.addEventListener('load', revealOnScroll);

document.addEventListener('DOMContentLoaded', () => {
  const dateInput = document.querySelector('input[type="date"]');
  if (dateInput) dateInput.setAttribute('min', new Date().toISOString().split('T')[0]);
  checkLoginStatus();
  setDailyMenu();
  setRating(5);
});